# Generated migration for adding performance indexes to Transaction model

from django.db import migrations, models, connection


def create_transaction_indexes_if_not_exist(apps, schema_editor):
    """Create transaction indexes only if they don't already exist"""
    
    indexes_to_create = [
        ('banking_transaction', 'banking_tra_acc_date_idx',
         'CREATE INDEX banking_tra_acc_date_idx ON banking_transaction (account_id, date)'),
        ('banking_transaction', 'banking_tra_type_date_idx',
         'CREATE INDEX banking_tra_type_date_idx ON banking_transaction (type, date)'),
        ('banking_transaction', 'banking_tra_cat_date_idx',
         'CREATE INDEX banking_tra_cat_date_idx ON banking_transaction (category, date)'),
        ('banking_transaction', 'banking_tra_complex_idx',
         'CREATE INDEX banking_tra_complex_idx ON banking_transaction (account_id, type, date DESC)'),
    ]
    
    with connection.cursor() as cursor:
        # First check if table exists
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_schema = 'public' 
                AND table_name = 'banking_transaction'
            );
        """)
        
        if not cursor.fetchone()[0]:
            print("Table banking_transaction does not exist, skipping indexes")
            return
        
        for table_name, index_name, create_sql in indexes_to_create:
            # Check if index already exists
            cursor.execute("""
                SELECT EXISTS (
                    SELECT 1 FROM pg_indexes 
                    WHERE tablename = %s 
                    AND indexname = %s
                );
            """, [table_name, index_name])
            
            if not cursor.fetchone()[0]:
                try:
                    cursor.execute(create_sql)
                    print(f"Created index: {index_name}")
                except Exception as e:
                    print(f"Warning: Could not create index {index_name}: {e}")
            else:
                print(f"Index {index_name} already exists, skipping")


def remove_transaction_indexes(apps, schema_editor):
    """Remove transaction indexes for rollback"""
    index_names = [
        'banking_tra_acc_date_idx',
        'banking_tra_type_date_idx',
        'banking_tra_cat_date_idx',
        'banking_tra_complex_idx',
    ]
    
    with connection.cursor() as cursor:
        for index_name in index_names:
            cursor.execute(f"DROP INDEX IF EXISTS {index_name};")


class Migration(migrations.Migration):

    dependencies = [
        ('banking', '0008_delete_consent'),
    ]

    operations = [
        migrations.RunPython(
            create_transaction_indexes_if_not_exist,
            remove_transaction_indexes,
            elidable=False
        ),
    ]