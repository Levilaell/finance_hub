# Manual migration to add missing ai_credits_balance field
from django.db import migrations, models, connection


def add_ai_credits_balance_if_not_exists(apps, schema_editor):
    """Add ai_credits_balance field only if it doesn't exist"""
    
    with connection.cursor() as cursor:
        # Check if column already exists
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.columns 
                WHERE table_schema = 'public'
                AND table_name = 'companies_company'
                AND column_name = 'ai_credits_balance'
            );
        """)
        
        column_exists = cursor.fetchone()[0]
        
        if not column_exists:
            cursor.execute("""
                ALTER TABLE companies_company 
                ADD COLUMN ai_credits_balance INTEGER DEFAULT 0 NOT NULL;
            """)
            print("Added ai_credits_balance column to companies_company")
        else:
            print("Column ai_credits_balance already exists, skipping")


def remove_ai_credits_balance(apps, schema_editor):
    """Remove ai_credits_balance field for rollback"""
    with connection.cursor() as cursor:
        cursor.execute("""
            ALTER TABLE companies_company 
            DROP COLUMN IF EXISTS ai_credits_balance;
        """)


class Migration(migrations.Migration):

    dependencies = [
        ('companies', '0009_merge_20250803_2225'),
    ]

    operations = [
        migrations.RunPython(
            add_ai_credits_balance_if_not_exists,
            remove_ai_credits_balance,
            elidable=False
        ),
    ]