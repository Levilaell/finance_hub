# Generated manually to fix database schema

from django.db import migrations, models, connection


def add_notification_fields_if_not_exist(apps, schema_editor):
    """Add notification fields only if they don't exist"""
    
    with connection.cursor() as cursor:
        # First check if table exists
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_schema = 'public' 
                AND table_name = 'resource_usage'
            );
        """)
        
        if not cursor.fetchone()[0]:
            print("Table resource_usage does not exist, skipping notification fields")
            return
        
        # Check and add notified_80_percent
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.columns 
                WHERE table_schema = 'public'
                AND table_name = 'resource_usage'
                AND column_name = 'notified_80_percent'
            );
        """)
        
        if not cursor.fetchone()[0]:
            cursor.execute("""
                ALTER TABLE resource_usage 
                ADD COLUMN notified_80_percent BOOLEAN DEFAULT FALSE NOT NULL;
            """)
            print("Added notified_80_percent column to resource_usage")
        else:
            print("Column notified_80_percent already exists, skipping")
        
        # Check and add notified_90_percent
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.columns 
                WHERE table_schema = 'public'
                AND table_name = 'resource_usage'
                AND column_name = 'notified_90_percent'
            );
        """)
        
        if not cursor.fetchone()[0]:
            cursor.execute("""
                ALTER TABLE resource_usage 
                ADD COLUMN notified_90_percent BOOLEAN DEFAULT FALSE NOT NULL;
            """)
            print("Added notified_90_percent column to resource_usage")
        else:
            print("Column notified_90_percent already exists, skipping")


def remove_notification_fields(apps, schema_editor):
    """Remove notification fields for rollback"""
    with connection.cursor() as cursor:
        cursor.execute("""
            ALTER TABLE resource_usage 
            DROP COLUMN IF EXISTS notified_80_percent,
            DROP COLUMN IF EXISTS notified_90_percent;
        """)


class Migration(migrations.Migration):

    dependencies = [
        ('companies', '0011_merge_fixup'),
    ]

    operations = [
        migrations.RunPython(
            add_notification_fields_if_not_exist,
            remove_notification_fields,
            elidable=False
        ),
    ]