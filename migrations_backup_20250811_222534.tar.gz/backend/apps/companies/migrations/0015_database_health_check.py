"""
Database health check and cleanup migration
Ensures database is in a consistent state after all migrations
"""
from django.db import migrations, connection
import logging

logger = logging.getLogger(__name__)


def database_health_check(apps, schema_editor):
    """
    Comprehensive database health check and cleanup
    Fixes common migration issues and ensures consistency
    """
    
    with connection.cursor() as cursor:
        # 1. Check and fix duplicate indexes
        cursor.execute("""
            SELECT 
                schemaname,
                tablename,
                indexname,
                indexdef
            FROM pg_indexes
            WHERE schemaname = 'public'
            AND tablename LIKE 'companies_%'
            ORDER BY tablename, indexname;
        """)
        
        indexes = cursor.fetchall()
        index_definitions = {}
        duplicates = []
        
        for schema, table, index_name, index_def in indexes:
            # Normalize the index definition for comparison
            normalized_def = index_def.lower().replace(' ', '')
            
            if normalized_def in index_definitions:
                # Found a duplicate
                duplicates.append((index_name, index_definitions[normalized_def]))
                logger.warning(f"Found duplicate index: {index_name} duplicates {index_definitions[normalized_def]}")
            else:
                index_definitions[normalized_def] = index_name
        
        # Remove duplicate indexes (keep the first one)
        for duplicate, original in duplicates:
            try:
                cursor.execute(f"DROP INDEX IF EXISTS {duplicate} CASCADE;")
                logger.info(f"Removed duplicate index: {duplicate}")
            except Exception as e:
                logger.warning(f"Could not remove duplicate index {duplicate}: {e}")
        
        # 2. Check for orphaned constraints
        cursor.execute("""
            SELECT 
                conname,
                conrelid::regclass AS table_name,
                contype
            FROM pg_constraint
            WHERE connamespace = 'public'::regnamespace
            AND conrelid::regclass::text LIKE 'companies_%'
            AND NOT EXISTS (
                SELECT 1 FROM pg_class 
                WHERE oid = conrelid
            );
        """)
        
        orphaned_constraints = cursor.fetchall()
        for constraint_name, table_name, constraint_type in orphaned_constraints:
            logger.warning(f"Found orphaned constraint: {constraint_name} on {table_name}")
        
        # 3. Verify critical tables exist
        critical_tables = [
            'companies_company',
            'companies_paymenthistory',
            'companies_subscriptionplan',
            'resource_usage',
        ]
        
        for table in critical_tables:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_schema = 'public' 
                    AND table_name = %s
                );
            """, [table])
            
            exists = cursor.fetchone()[0]
            if not exists:
                logger.warning(f"Critical table missing: {table}")
        
        # 4. Check for columns that should exist but might be missing
        column_checks = [
            ('companies_company', 'ai_credits_balance'),
            ('companies_company', 'enable_ai_categorization'),
            ('companies_company', 'enable_ai_insights'),
            ('companies_company', 'subscription_plan'),
            ('companies_company', 'subscription_status'),
        ]
        
        for table, column in column_checks:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.columns 
                    WHERE table_schema = 'public'
                    AND table_name = %s 
                    AND column_name = %s
                );
            """, [table, column])
            
            exists = cursor.fetchone()[0]
            if not exists:
                logger.warning(f"Column missing: {table}.{column}")
                
                # Try to add missing columns with safe defaults
                if table == 'companies_company':
                    if column == 'ai_credits_balance':
                        try:
                            cursor.execute("""
                                ALTER TABLE companies_company 
                                ADD COLUMN IF NOT EXISTS ai_credits_balance INTEGER DEFAULT 0;
                            """)
                            logger.info(f"Added missing column: {column}")
                        except Exception as e:
                            logger.error(f"Could not add column {column}: {e}")
                    elif column in ['enable_ai_categorization', 'enable_ai_insights']:
                        try:
                            cursor.execute(f"""
                                ALTER TABLE companies_company 
                                ADD COLUMN IF NOT EXISTS {column} BOOLEAN DEFAULT false;
                            """)
                            logger.info(f"Added missing column: {column}")
                        except Exception as e:
                            logger.error(f"Could not add column {column}: {e}")
        
        # 5. Fix any NULL values in critical non-nullable fields
        cursor.execute("""
            UPDATE companies_company 
            SET ai_credits_balance = 0 
            WHERE ai_credits_balance IS NULL;
        """)
        
        cursor.execute("""
            UPDATE companies_company 
            SET enable_ai_categorization = false 
            WHERE enable_ai_categorization IS NULL;
        """)
        
        cursor.execute("""
            UPDATE companies_company 
            SET enable_ai_insights = false 
            WHERE enable_ai_insights IS NULL;
        """)
        
        # 6. Verify and fix foreign key constraints
        cursor.execute("""
            SELECT
                tc.table_name,
                kcu.column_name,
                ccu.table_name AS foreign_table_name,
                ccu.column_name AS foreign_column_name
            FROM information_schema.table_constraints AS tc
            JOIN information_schema.key_column_usage AS kcu
                ON tc.constraint_name = kcu.constraint_name
                AND tc.table_schema = kcu.table_schema
            JOIN information_schema.constraint_column_usage AS ccu
                ON ccu.constraint_name = tc.constraint_name
                AND ccu.table_schema = tc.table_schema
            WHERE tc.constraint_type = 'FOREIGN KEY'
            AND tc.table_schema = 'public'
            AND tc.table_name LIKE 'companies_%';
        """)
        
        foreign_keys = cursor.fetchall()
        for table, column, foreign_table, foreign_column in foreign_keys:
            # Check if referenced table exists
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_schema = 'public' 
                    AND table_name = %s
                );
            """, [foreign_table])
            
            if not cursor.fetchone()[0]:
                logger.error(f"Foreign key references non-existent table: {table}.{column} -> {foreign_table}")
        
        logger.info("Database health check completed")


def reverse_health_check(apps, schema_editor):
    """
    Health check is not reversible
    """
    pass


class Migration(migrations.Migration):
    
    dependencies = [
        ('companies', '0014_cleanup_orphan_tables'),
    ]
    
    operations = [
        migrations.RunPython(
            database_health_check,
            reverse_health_check,
            elidable=False
        ),
    ]